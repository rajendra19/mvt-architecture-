from django import forms
from myapp.models import Product

class UserForm(forms.ModelForm):
    class Meta:
        model = Product
        #fields = '__all__'   (we can do this type of coding also using "__all__" attributes)
        fields = ('name', 'description', 'price')

        widgets = {

            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description':forms.TextInput(attrs={'class': 'form-control'}),
            'price': forms.NumberInput(attrs={'class': 'form-control'}),
        }

