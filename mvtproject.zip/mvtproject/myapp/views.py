from django.contrib.auth.decorators import login_required
from django.shortcuts import render,redirect
from myapp.models import Product
from myapp.forms import UserForm
from django.http import HttpResponse
# Create your views here.
@login_required
def insert(request):
    if request.method=='POST':
        form = UserForm()
        if form.is_valid():
            try:
                form.save()
                return HttpResponse('<h2>Data inserted into database</h2>')
            except:
                pass
        form=UserForm()
        return render(request,'index.html',{"form":form})

def show(request):
    users=Product.objects.all()
    return render(request,'show.html',{'users':users})

@login_required
def edit(request,id):
    user=Product.objects.get(id=id)
    return render(request,'edit.html',{"user":user})

@login_required
def delete(request,id):
    user = Product.objects.get(id=id)
    user.delete()
    return redirect('/show')

